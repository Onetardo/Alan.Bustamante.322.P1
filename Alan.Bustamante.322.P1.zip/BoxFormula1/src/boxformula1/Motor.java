package boxformula1;

public class Motor extends Pieza implements Ajustable {
    private int potenciaMaxima;

    public Motor(int potenciaMaxima, String nombre, String ubicacionBox, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, condicionClimatica);
        this.potenciaMaxima = potenciaMaxima;
    }
    
    
    
    public void ajustar(){
        System.out.println("ajustado motor");
    }

    @Override
    public String toString() {
        return "Motor\n" + super.toString() + ", Potencia Maxima: " + potenciaMaxima;
    }
    
    
}
