package boxformula1;

import java.util.ArrayList;

public class RegistroPiezas {
    private Pieza pieza;
    private ArrayList<Pieza> piezas;

    public RegistroPiezas() {
        this.piezas = new ArrayList<>() ;
    }
    
    
    
    private boolean piezaRepetida(Pieza nuevaPieza){
        for (Pieza pieza : piezas){
            if (pieza.existePieza(nuevaPieza)){
                return true;
            }      
        }
        return false;
    }
   
    public void agregarPieza(Pieza pieza){
        if(piezaRepetida(pieza)){
            throw new PiezaExistenteException("esta pieza ya existe con nombre: " + this.pieza.getNombre() + 
                                              "en la ubicacion: " + this.pieza.getUbicacionBox());
        }else{
        piezas.add(pieza);
        }
    }
    
    public void  mostrarPiezas(){
        for(Pieza pieza : piezas){
            System.out.println(pieza.toString());
        }
    }
    
    public void ajustarPiezas(){
        for (Pieza pieza : piezas){
            if (pieza instanceof Ajustable a){
                a.ajustar();
            }
            else{
                System.out.println("Esta pieza no se puede ajustar");
            }
        }
    }
    
    public ArrayList<Pieza> buscarPiezasPorCondicion(CondicionClimatica condicion){
        ArrayList<Pieza> piezasFiltradas = new ArrayList<>();
        for (Pieza pieza : piezas){
            if (pieza.getCondicionClimatica().equals(condicion)){
                piezasFiltradas.add(pieza);
                System.out.println(pieza.toString());
            }
        }
        return piezasFiltradas;
    }
    
   
}
