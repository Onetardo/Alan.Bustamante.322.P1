package boxformula1;

public enum Compuesto {
    SOFT,
    MEDIUM,
    HARD,
    INTERMEDIO,
    WET;
}
