package boxformula1;

public class CargaAerodinamicaExcedida extends Exception {
    private static final String MESSAGE = "La carga aerodinamica esta excedida";
    
    public CargaAerodinamicaExcedida(){
        this(MESSAGE);
        
    }
    public CargaAerodinamicaExcedida(String mensaje){
        super(mensaje);
    }
}
