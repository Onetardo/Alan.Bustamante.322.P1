package boxformula1;

public abstract class Pieza {
    private String nombre;
    private String ubicacionBox;
    private CondicionClimatica condicionClimatica;

    public Pieza(String nombre, String ubicacionBox, CondicionClimatica condicionClimatica) {
        this.nombre = nombre;
        this.ubicacionBox = ubicacionBox;
        this.condicionClimatica = condicionClimatica;
    }
    
    public boolean existePieza (Pieza pieza){
        if (this.getNombre().equals(pieza.getNombre()) && this.getUbicacionBox().equals(pieza.getUbicacionBox())){
            return true;
        }
        return false;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacionBox() {
        return ubicacionBox;
    }

    public CondicionClimatica getCondicionClimatica() {
        return condicionClimatica;
    }

    @Override
    public String toString() {
        return "Pieza:\n" + "nombre: " + nombre + ", ubicacionBox: " + ubicacionBox + ", condicionClimatica: " + condicionClimatica;
    }
    
    
}
