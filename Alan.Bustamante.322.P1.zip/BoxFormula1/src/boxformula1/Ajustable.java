package boxformula1;

public interface Ajustable {
    public abstract void ajustar();
}
