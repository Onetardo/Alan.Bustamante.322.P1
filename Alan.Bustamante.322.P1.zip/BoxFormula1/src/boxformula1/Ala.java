package boxformula1;

public class Ala extends Pieza implements Ajustable{
    private int cargaAerodinamica;
    private static final int CARGA_MINIMA = 1;
    private static final int CARGA_MAXIMA = 10;

    public Ala(int cargaAerodinamica, String nombre, String ubicacionBox, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, condicionClimatica);
        this.cargaAerodinamica = cargaAerodinamica;
    }
    
    public void ajustar(){
        System.out.println("ajustado ala");
    }

    @Override
    public String toString() {
        return "Ala\n" + super.toString() + ", Carga Aerodinamica: " + cargaAerodinamica;
    }
    
    
}
