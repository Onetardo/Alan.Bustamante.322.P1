package boxformula1;

public class Neumatico extends Pieza {
    private Compuesto compuesto;

    public Neumatico(Compuesto compuesto, String nombre, String ubicacionBox, CondicionClimatica condicionClimatica) {
        super(nombre, ubicacionBox, condicionClimatica);
        this.compuesto = compuesto;
    }

    @Override
    public String toString() {
        return "Neumatico\n" + super.toString() + ", compuesto: " + compuesto;
    }
    
    
    
}
