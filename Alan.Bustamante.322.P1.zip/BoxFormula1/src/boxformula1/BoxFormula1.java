package boxformula1;

public class BoxFormula1 {

    public static void main(String[] args) throws CargaAerodinamicaExcedida {
        RegistroPiezas ingeniero =  new RegistroPiezas();
        
        Motor m1 = new Motor(100, "PU-016", "Estacion Motor", CondicionClimatica.SECO);
        Motor m2 = new Motor(100, "PU-016", "Estacion Motor", CondicionClimatica.SECO);
        Ala a1 = new Ala(5, "XC-192", "Estacion Ala", CondicionClimatica.MIXTO);
        Neumatico n1 = new Neumatico(Compuesto.HARD, "ZLS-102", "Estacion Neumatico", CondicionClimatica.LLUVIA);
        //1.
        /**
        ingeniero.agregarPieza(m1);
        ingeniero.agregarPieza(m2);
        **/
        
        //2.
        ingeniero.agregarPieza(m1);
        ingeniero.agregarPieza(a1);
        ingeniero.agregarPieza(n1);
       
        ingeniero.mostrarPiezas();
        
        
        //3.
        
        ingeniero.ajustarPiezas();
        
        //4.
        
        ingeniero.buscarPiezasPorCondicion(CondicionClimatica.SECO);
        
        
        
        
        
        
        
        
    }
    
}
