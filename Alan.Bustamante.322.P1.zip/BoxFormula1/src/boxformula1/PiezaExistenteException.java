package boxformula1;

public class PiezaExistenteException extends RuntimeException {
    private static final String MESSAGE = "Esta pieza ya existe";
    
    public PiezaExistenteException(){
        this(MESSAGE);
        
    }
    public PiezaExistenteException(String mensaje){
        super(mensaje);
    }
}
